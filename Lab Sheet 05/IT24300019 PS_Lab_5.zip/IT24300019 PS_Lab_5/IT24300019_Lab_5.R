getwd()
setwd("C:/Users/Havindu Sineth/Desktop/IT24300019 PS_Lab_5")
Delivery_Times <- read.table("Exercise.txt", header = TRUE)
fix(Delivary_times)
attach(Delivary_times)
names(Delivary_times)<-c("T1")

hist(T1,main = "histogrem for T1" )

histogrem <- hist(T1,main = "histogrem for T1",breaks =seq(20,70),right =FALSE )
breaks_seq <seq(20,70,length =10 )

hist(data$T1 ,right =FALSE ,main ="histogrem of delivary atimes",xlab = T1
     )
