getwd()
setwd("C:/Users/it24300019/Desktop/IT24300019 Lab_6")

#Q1
  #Part 1 )
    # the Distribution is Bionomial  Distribution

  #Part 2)
    dbinom(46,50,0.85)

#Q2
#part 1 
    #RAndom Variable(X) - No of calls in an one hour 
#Part 2
    #poission Distribution with lamda = 12
#part 3
    dpois(15 ,12)
    
    
    
